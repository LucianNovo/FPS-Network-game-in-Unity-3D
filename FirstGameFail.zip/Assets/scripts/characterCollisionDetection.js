#pragma strict

function Start () {

}

function Update () {

}


//detects if something has entered the same 3d space as the 
//current object(a character controller, or gameobject with a collider).
//This is one of the implicit functions that will respond to something happening in the unity game, these implicit functions
//usually start with 'On'
function OnTriggerEnter(other:Collider){
	if(other.gameObject.tag == "bullet")//if object entering the current object is tagged with "bullet" (which is configured in the bullet_pfb)
	{
		Debug.Log("Collider Detected");//shows up in the debug panel
		Destroy(other.gameObject);//destroys the other object(the bullet prefab in this case)
	}
}

function OnCollisionEnter (other : Collision)//
{ 
	Debug.Log("DEATH");
    if (other.gameObject.name == "bullet_pfb") { 
       Debug.Log("Collision");
   } 
}